/* See step-by-step tutorial on how to create this at
https://youtu.be/8eyAoBBucHk


Want more? Visit for our CSS beginner tutorials!
redstapler.co
*/