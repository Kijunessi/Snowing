# Pure CSS Snow Fall Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/redstapler/pen/MZXJZx](https://codepen.io/redstapler/pen/MZXJZx).

